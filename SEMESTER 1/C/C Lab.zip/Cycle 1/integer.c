#include <stdio.h>
int main()
{
	int num;
	printf("Enter an integer: ");
	scanf("%d", &num);
	printf("You entered: %d\n", num);
}
